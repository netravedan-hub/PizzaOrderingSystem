import { Component } from '@angular/core';
import { FooterComponent } from './SiteLayout/footer/footer.component';
import { HeaderComponent } from './SiteLayout/header/header.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Pizza-Ordering-System';
}
