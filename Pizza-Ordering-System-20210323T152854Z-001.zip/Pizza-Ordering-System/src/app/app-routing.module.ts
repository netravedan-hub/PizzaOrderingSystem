import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomiseComponent } from './Products/customise/customise.component';
import { ProductDetailsComponent } from './Products/product-details/product-details.component';
import { ShoppingCartComponent } from './Products/shopping-cart/shopping-cart.component';

import { FooterComponent } from './SiteLayout/footer/footer.component';
import { HeaderComponent } from './SiteLayout/header/header.component';

const routes: Routes = [ 

  { path: '', component: ProductDetailsComponent },
  { path: 'products/:cat', component: ProductDetailsComponent },
  {path:'product/:id', component: CustomiseComponent },
  {path:'cart', component: ShoppingCartComponent }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
