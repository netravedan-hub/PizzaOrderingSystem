import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Products } from 'src/app/Model/product';
import { Toppings } from 'src/app/Model/toppings';
import { ProductsService } from '../services/products.service';

@Component({
  selector: 'app-customise',
  templateUrl: './customise.component.html',
  styleUrls: ['./customise.component.css']
})
export class CustomiseComponent implements OnInit {
  public pizzaSize:string[]=[] ; //size dropdown array
  public pizzaCrust:string[]=[] ; //crust dropdown array
  public selectedProduct:any;
  productList: Products[] | undefined;
  public product:any;
  public totalPrice:number=0;
  public selectToppings:string[]=[];////selected toppings from dropdown
  public selectedSize="";//selected size from dropdown
  public selectedCrust="";//selected crust from dropdown
  public isCheeseAdded:boolean=false;//selected crust from dropdown

//veg toppings list
  public vegToppingsList:Toppings[] = [
    {name:"Onion",ImgUrl:"assets/Images/VegToppings/Onion.jpg",price:35},
    {name:"Capsicum",ImgUrl:"assets/Images/VegToppings/Capsicum.jpg",price:35},
    {name:"Mushroom",ImgUrl:"assets/Images/VegToppings/Mushroom.png",price:35}
    
    ];

    //non veg toppings list
  public nonVegToppingsList:Toppings[] = [
    {name:"Peri-Peri Chicken",ImgUrl:"assets/Images/NonVegToppings/periperi.jpg",price:35},
    {name:"Chicken Sausage",ImgUrl:"assets/Images/NonVegToppings/chickensausage.jpg",price:35},
    {name:"Chicken Keema",ImgUrl:"assets/Images/NonVegToppings/chickenKeem.jpg",price:35}
   
   ];
  
   
  constructor(private _route:ActivatedRoute,private route:Router,private productService:ProductsService) { }

  ngOnInit(): void {
  //Size and crust get initialised with the values 
   this.pizzaSize=['Small','Medium','Large'];
   this.pizzaCrust=['Wheat','Wheat Thin Crust','Cheese Burst','Fresh Pan Pizza'];
   this.loadProduct();
  }


 //this method gets call on load  to display details of product selected from product details page
loadProduct()
{
  
  const id=+this._route.snapshot.params['id'];
  this.product=this.productService.getProduct(id);
  this.productService.getProduct(id).subscribe(
    res=>{
    this.product=res;
  })
  console.log(this.product);
  this.totalPrice=this.product.ProductPrice;
}

//this is called whenever toppings are added and removed to display the sub total
updateSubTotal(price:number){
this.totalPrice=this.totalPrice+price;
}

//this is called when toppings are added
AddToppings(topping:string){
this.selectToppings.push(topping);
this.updateSubTotal(50);


}
//this is called when toppings are removed
RemoveToppings(){
  debugger;
  this.selectToppings.pop();
  this.updateSubTotal(-50);
  
  }

  //when values from crust dropdown are changed
  selectCrustChangeHandler(event:any){
    this.selectedCrust=event.target.value;
  }

  //when values from size dropdown are changed
  selectSizeChangeHandler(event:any){
    this.selectedSize=event.target.value;
  }

  //this is called when checkbox is checked/unchecked
  OnCheckBoxChecked(event:any){
  this.isCheeseAdded=event.target.checked;
  }

  //customised product gets added to cart
  AddToCart(product:Products)
  {
    
    product.SelectedToppings=this.selectToppings.toString();
    product.TotalPrice=this.totalPrice;
    product.Size=this.selectedSize;
    product.Crust=this.selectedCrust;
    product.IsCheeseAdded=this.isCheeseAdded;
    this.productService.addProductsToCart(product);
  
  }

}
