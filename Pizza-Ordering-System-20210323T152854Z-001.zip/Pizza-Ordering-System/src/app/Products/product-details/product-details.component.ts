import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {  Products } from 'src/app/Model/product';
import { ProductsService } from '../services/products.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  productList:any=[];
  productCat:string|undefined;
  constructor(private ps:ProductsService,private router:Router,private http:HttpClient,private _route:ActivatedRoute) { 
  
  }

  ngOnInit(): void {
    debugger;
    this.productCat=this._route.snapshot.params['cat'];
    if(this.productCat==undefined || this.productCat=="All"){
    this.GetProducts();
    }
    else
    {
      this.ps.getProductCategorywise(this.productCat).subscribe(
        res=>{
        this.productList=res;
      }

      );
    
    }
}

    LoadAddOnComponent(productId:number){
    this.router.navigate(['product',productId]);
    }

     GetProducts(){
      this.ps.getProducts().subscribe(
        res=>{
        this.productList=res;
        
  
      }
);
}

AddProductToCart(product:Products){
  this.ps.addProductsToCart(product);
}

}
