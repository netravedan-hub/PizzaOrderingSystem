import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Products } from 'src/app/Model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  cartProducts:Products[]=[];
  constructor(private http:HttpClient) { }

  private baseUrl:string = "http://localhost:62651/";

  //returns all products
  
  getProducts(){
  return this.http.get(this.baseUrl+"api/Products/GetProductDetails");
   }

//gets a single product by Id
 getProduct(productId: any) {
return this.http.get(this.baseUrl + 'api/Products/GetProduct/'+ productId);
}

//returns products by category
getProductCategorywise(productCat: any){
  return this.http.get(this.baseUrl + 'api/Products/GetProductCategoryWise/'+ productCat);
}

//this is called when user places order
 placeProductOrder(data:any) {
  
  return this.http.post(this.baseUrl+"api/Products/PostProductDetails",data);

}

//product gets added to cart
 addProductsToCart(product:Products){
  this.cartProducts.push(product);
}

 //get products which are added to cart
  getCartProducts(){
   return this.cartProducts;
 }
}
