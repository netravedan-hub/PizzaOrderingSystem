import { Component, OnInit } from '@angular/core';
import { Products } from 'src/app/Model/product';
import { ProductsService } from '../services/products.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  cartProducts:Products[]=[];
  resultData:any;
  quantity:number=1;
  constructor(private productService:ProductsService)
   { 
     this.cartProducts=this.productService.getCartProducts();
   }

  ngOnInit(): void {
  }
  //Call given to web api to place order
  PlaceOrder(){
   
      this.productService.placeProductOrder(this.cartProducts).subscribe((resp:any) => {
      this.resultData=resp;
    });
  }
}
