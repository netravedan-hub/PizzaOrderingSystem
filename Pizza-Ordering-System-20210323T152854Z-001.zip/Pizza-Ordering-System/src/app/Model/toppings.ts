export class Toppings
{
    constructor(public name:string,public price:number,
       public ImgUrl:string)
    {

    }
    

}