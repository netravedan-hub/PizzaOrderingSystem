export class Products
{
   
constructor(public ProductName:string,public ProductId:number,public ProductPrice:number,public ProductDescription:string,public ProductCategory:string,public TotalPrice:number,public ImgUrl:string,public SelectedToppings:string,public Size:string,public Crust:string,public IsCheeseAdded:boolean)
{
    
}
   


}

