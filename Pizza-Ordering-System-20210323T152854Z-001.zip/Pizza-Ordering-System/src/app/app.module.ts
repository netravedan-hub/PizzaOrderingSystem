import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CustomiseComponent } from './Products/customise/customise.component';
import { ProductDetailsComponent } from './Products/product-details/product-details.component';
import { FooterComponent } from './SiteLayout/footer/footer.component';
import { HeaderComponent } from './SiteLayout/header/header.component';

import { ShoppingCartComponent } from './Products/shopping-cart/shopping-cart.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    CustomiseComponent,
    ProductDetailsComponent,
    FooterComponent,
    HeaderComponent,
    ShoppingCartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
