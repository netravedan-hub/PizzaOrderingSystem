﻿using ProductsWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace ProductsWebAPI.Controllers
{
    [EnableCors(origins: "http://localhost:62651", headers: "*", methods: "*")]
    public class ProductsController : ApiController
    {

       
        // GET api/values
        [HttpGet]
        [Route("api/Products/GetProductDetails")]
        public List<Products> GetProductDetails()
        {
            List<Products> listProducts = FillProducts();
            return listProducts;
        }


        public List<Products> FillProducts()
        {
            List<Products> productList = new List<Products>() {
                    new Products() { ProductId = 1, ProductName = "Marghareta",ProductPrice=100,ProductDescription="A hugely popular margherita, with a deliciously tangy single cheese topping",ImgUrl="assets/Images/VegPizza/Marghareta.jpg",ProductCategory="VegPizza"} ,
                    new Products() { ProductId = 2, ProductName = "Farm House",ProductPrice=100,ProductDescription="Farm House Pizza with overload of crunchy, crisp capsicum,succulent mushrooms and fresh tomatoes",ImgUrl="assets/Images/VegPizza/Farmhouse.jpg",ProductCategory="VegPizza"} ,
                    new Products() { ProductId = 3, ProductName = "Pepper Barbeque Chicken",ProductPrice=100,ProductDescription="Pepper barbecue chicken for that extra zing",ImgUrl="assets/Images/NonVeg/chicken_tikka.jpg",ProductCategory="NonVegPizza"} ,
                    new Products() { ProductId = 3, ProductName = "Indi Chicken Tikka",ProductPrice=100 ,ProductDescription="The wholesome flavour of tandoori masala with Chicken tikka, onion, red paprika & mint mayo",ImgUrl="assets/Images/NonVeg/Pepper_Barbeque.jpg",ProductCategory="NonVegPizza"},
                    new Products() { ProductId = 4, ProductName = "Garlic Breadsticks",ProductPrice=100,ProductDescription="Baked to perfection. Your perfect pizza partner! Tastes best with dip",ImgUrl="assets/Images/Sides/Breadsticks.jpeg",ProductCategory="Sides" } ,
                    new Products() { ProductId = 5, ProductName = "Veg Nuggets",ProductPrice=100,ProductDescription ="Crisp and golden outside, flavorful burst of cheese, potato & spice inside",ImgUrl="assets/Images/Sides/Vegnuggets.jpg",ProductCategory="Sides"},
                    new Products() { ProductId = 4, ProductName = "Coke",ProductPrice=100,ProductDescription="Coke",ImgUrl="assets/Images/Beverages/coke.JPG",ProductCategory="Beverages" } ,
                    new Products() { ProductId = 5, ProductName = "Fanta",ProductPrice=100,ProductDescription ="Great Mango Taste",ImgUrl="assets/Images/Beverages/Fanta.png",ProductCategory="Beverages"},
                    new Products() { ProductId = 4, ProductName = "Apple Pie",ProductPrice=100,ProductDescription="Apple Pie",ImgUrl="assets/Images/Deserts/Applepie.jpg",ProductCategory="Deserts" } ,
                    new Products() { ProductId = 5, ProductName = "Banana Pudding",ProductPrice=100,ProductDescription ="Banana Pudding",ImgUrl="assets/Images/Deserts/Bananapudding.jpg",ProductCategory="Deserts"}
                };
            return productList;
        }

        // GET api/values/5

        [HttpGet]
        [Route("api/Products/GetProduct/{productId}")]
        public Products GetProduct(int productId)
        {
            List<Products> listProducts = FillProducts();
            Products prod = listProducts.Find(a => a.ProductId == productId);
            return prod;
        }

        [HttpGet]
        [Route("api/Products/GetProductCategoryWise/{productCat}")]
        public List<Products> GetProductCategoryWise(string productCategory)
        {
            List<Products> listProducts = FillProducts();
            listProducts = listProducts.FindAll(a => a.ProductCategory == productCategory);
            return listProducts;
        }

        // POST api/values
        [HttpPost]
        [Route("api/Products/PostProductDetails")]
        public HttpResponseMessage PostProductDetails(List<Products> products)
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }

      
    }
}
