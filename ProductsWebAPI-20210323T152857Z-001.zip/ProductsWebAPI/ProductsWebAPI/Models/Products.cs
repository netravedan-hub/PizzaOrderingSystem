﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductsWebAPI.Models
{
    public class Products
    {
        public string ProductName { get; set; }
        public int ProductId { get; set; }
        public double ProductPrice { get; set; }
        public string ProductDescription { get; set; }
        public string ProductCategory { get; set; }

        public string ImgUrl { get; set; }

        public double TotalPrice { get; set; }

        public string SelectedToppings { get; set; }

        public string Size { get; set; }

        public string Quantity { get; set; }

        public string Crust { get; set; }
    }


}